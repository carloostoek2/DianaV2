> ⚠️ Copia del kit, actualizada el 2026-10-15 con lo que dicen los reportes. La versión vigente y completa vive en el repo (`audit/contracts/`); si difieren, manda el repo.

# C-HIST-01 — El historial de la dueña y de los VIP se captura y se reimporta de verdad

ID:            C-HIST-01
Promesa:       (a) Cada mensaje que la dueña envía por Diana queda en el historial del VIP (pares texto ↔ id de Telegram). (b) El historial previo del VIP se importa desde la cuenta de Telegram de la dueña, lentamente, un VIP por ciclo, para que Diana aprenda su voz y contexto.
Fuente:        wiki/entities/modulos/jobs.md; docs/SPEC-FASE5/6; application/owner_history.py, vip_history_seed.py, history_reimport.py
Disparador:    (a) entrega exitosa de un turno / corrección / recontacto; (b) job de reimport cada history_reimport_interval_sec.
Efecto:        (a) filas en historial con texto y message_id tras cada entrega; (b) historial de VIPs ampliado, cursor de reimport avanzando, cola de backfill de memoria alimentada.
Banderas:      (b) feature_history_reimport_enabled Y configuración de Telethon completa (api_id/hash/sesión) Y vip_history_seed_limit.
Camino (estático, SIN ejecutar):
  (a) orchestrator / admin_service / recontact_service → append_owner_delivery_history → build_owner_history_pairs.
  (b) main.py:285 → HistoryReimportJob → HistoryReimportService (composition.py:1406) ← requiere flag Y history_seed.enabled.
Puntos ciegos (EVIDENCIA EN CÓDIGO):
  - composition.py:228 `vip_history_seed_disabled_missing_telethon_config`: si falta configuración, el import queda apagado solo con un log info; no hay alerta.
  - composition.py:1406-1408: el servicio de reimport solo se crea si bandera Y seed habilitado; cualquiera de los dos faltantes ⇒ no existe, sin error.
  - Sandbox: el historial se omite por diseño (`owner_history_skipped_sandbox`); un chat marcado como sandbox por error dejaría de grabar sin avisar.
  - La sesión de Telethon es del mundo real: no se puede probar E2 completo sin credenciales ni cuenta; requiere fake de Telethon (solo esa frontera).
Prueba E2:     (a) pendiente: entrega real → asertar filas de historial con message_id. (b) pendiente: FakeTelethon con mensajes sembrados → un ciclo del job real → asertar historial + cursor + cola de backfill; segundo ciclo idempotente.
Sabotaje E3:   pendiente → S2 (bandera OFF), S1 (seed=None), quitar la llamada a append_owner_delivery_history.
Vigilante E4:  propuesto → (a) turnos DELIVERED sin fila de historial en 24h; (b) VIPs sin importar / cursor sin avanzar en > N intervalos con la bandera ON.
Nivel:         E0
Semáforo:      (a) captura: 🟡 15.688 filas, todas con id. (b) recarga de VIP existentes: ⚪ apagada A PROPÓSITO desde 6-sep. CONFIRMADO por la dueña (2026-10-06): la sesión de Telethon es la de la cuenta VIEJA; la cuenta nueva no tiene historial con ningún VIP (todos escriben en chats nuevos; el historial anterior en Telegram se perdió; en la base sigue). PENDIENTE: el import al alta de VIP nuevo usa esa misma sesión y no puede encontrar chats de la cuenta nueva.
Hallazgos:     H3 confirmado y resuelto como decisión; falta registrar. Pregunta abierta: ¿qué cuenta usa la sesión Telethon y trae historial el alta de VIP nuevos? Ver INVESTIGACION-C.md

## Estado vigente (2026-10-15)
(a) Captura de cada entrega: 🟢 E3 (R2: entrega normal, corrección y recontacto dejan fila con texto y el número de mensaje exacto de Telegram; sandbox y promoción a no-VIP NO escriben, por diseño). Los 18 avisos de V4 eran promociones a chats no VIP: no son fallas. V4 debe ajustarse antes de activarse.
(b) Alta de VIP nuevo: 🟢 E3 (bandera `FEATURE_VIP_HISTORY_SEED_ENABLED`, hoy encendida desde 2026-10-08 05:58 UTC; confirmado en el arranque). Recarga de VIP existentes (`FEATURE_HISTORY_REIMPORT_ENABLED=false`): apagada a propósito desde 2026-09-06, declarada.
Por confirmar: el comentario del `.env` dice que el alta consulta "la sesión de la cuenta en uso", pero la dueña indicó que la sesión de Telethon es de la cuenta vieja.
Límite conocido: antes del alta solo se guarda lo que escribió Diana, no el lado del cliente.
