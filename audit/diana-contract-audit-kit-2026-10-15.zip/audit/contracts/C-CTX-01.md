> ⚠️ Copia del kit, actualizada el 2026-10-15 con lo que dicen los reportes. La versión vigente y completa vive en el repo (`audit/contracts/`); si difieren, manda el repo.

# C-CTX-01 — Contexto temporal interpretado (REQ-MEM-06)
ID: C-CTX-01
Promesa: después de cada turno se guarda una foto del estado de la conversación (espera respuesta, primer mensaje del día, día, hora); llega al modelo; al vencer se retira.
Fuente: SPEC-FASE2, REQ-MEM-06 · Banderas: FEATURE_CONTEXT_ENABLED (true en .env y system_config)
Hallazgo: la foto inyectaba claves del presente congeladas del turno anterior: `waiting_for_reply_since` en desacuerdo en 59 de 70 turnos (84 %), `is_first_message_of_day` en 15 de 70 (21 %).
Arreglo (desplegado 2026-10-07): las cuatro claves se derivan siempre en vivo del historial del turno; la foto solo aporta sus claves propias. Tras el arreglo, 0 % de desacuerdo (3 turnos medidos).
Pruebas: tests/audit/test_C_CTX_01.py (3 escenarios E2) + 2 sabotajes.
Nivel: 🟢 E3. Pendiente: vigilante de contenido (consulta propuesta en FASE2-CONTEXTO §9), no implementado.
